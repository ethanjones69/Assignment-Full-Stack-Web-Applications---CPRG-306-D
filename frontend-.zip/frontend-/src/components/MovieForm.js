import { useState } from 'react';
import axios from 'axios';

export default function MovieForm({ fetchMovies }) {
  const [form, setForm] = useState({ title: '', actors: '', year: '' });

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    await axios.post('/api/movies', {
      title: form.title,
      actors: form.actors.split(',').map(a => a.trim()),
      year: parseInt(form.year)
    });
    setForm({ title: '', actors: '', year: '' });
    fetchMovies();
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white shadow-md p-4 rounded-lg">
      <h2 className="text-lg font-bold mb-2">Add a Movie</h2>
      <input name="title" value={form.title} onChange={handleChange} placeholder="Title" className="border p-2 mb-2 w-full" required />
      <input name="actors" value={form.actors} onChange={handleChange} placeholder="Actors (comma-separated)" className="border p-2 mb-2 w-full" required />
      <input name="year" value={form.year} onChange={handleChange} placeholder="Release Year" type="number" className="border p-2 mb-2 w-full" required />
      <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">Add Movie</button>
    </form>
  );
}
