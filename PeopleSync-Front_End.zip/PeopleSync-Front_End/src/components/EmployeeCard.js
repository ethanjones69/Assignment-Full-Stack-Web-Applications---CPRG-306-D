import React from 'react';

const EmployeeCard = ({ employee }) => {
  return (
    <div className="bg-white w-full max-w-xl rounded-lg shadow-md p-6 hover:shadow-xl transition-shadow">
      <h3 className="text-xl font-bold text-gray-800 mb-2">{employee.name}</h3>
      <p className="text-gray-600"><strong>Role:</strong> {employee.role}</p>
      <p className="text-gray-600"><strong>Salary:</strong> ${employee.salary}</p>
      <p className="text-gray-600"><strong>Department:</strong> {employee.department}</p>
    </div>
  );
};

export default EmployeeCard;
