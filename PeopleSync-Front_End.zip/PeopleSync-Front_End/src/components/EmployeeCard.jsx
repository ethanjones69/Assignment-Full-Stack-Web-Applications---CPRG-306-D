export default function EmployeeCard({ employee }) {
    return (
      <div className="border rounded p-4 shadow">
        <h2 className="text-xl font-semibold">{employee.name}</h2>
        <p>{employee.position}</p>
        <p>{employee.department}</p>
        <p>Salary: ${employee.salary}</p>
      </div>
    );
  }
  