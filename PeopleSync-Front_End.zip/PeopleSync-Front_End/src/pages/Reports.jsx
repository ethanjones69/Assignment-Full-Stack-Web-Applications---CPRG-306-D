export default function Reports() {
    return (
      <div className="p-4">
        <h1 className="text-2xl font-bold">Reports</h1>
        <p>Generate and export employee reports here.</p>
      </div>
    );
  }
  