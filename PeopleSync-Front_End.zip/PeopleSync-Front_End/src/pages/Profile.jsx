export default function Profile() {
    return (
      <div className="p-4">
        <h1 className="text-2xl font-bold">My Profile</h1>
        <p>This is where employee profile info would go.</p>
      </div>
    );
  }
  