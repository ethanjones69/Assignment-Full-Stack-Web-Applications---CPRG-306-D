import React, { useEffect, useState } from 'react';
import axios from 'axios';
import EmployeeCard from '../components/EmployeeCard';

const Dashboard = () => {
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3000/api/employees')
      .then(res => setEmployees(res.data))
      .catch(err => console.error('Error fetching employees:', err));
  }, []);

  return (
    <div>
      <h2 className="text-2xl font-semibold text-center text-gray-700 mb-6">Current Employees</h2>
      <div className="flex flex-col gap-4 items-center">
        {employees.map(emp => (
          <EmployeeCard key={emp.id} employee={emp} />
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
