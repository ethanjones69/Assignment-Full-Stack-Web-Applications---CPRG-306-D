import { useState } from "react";
import api from "../services/api";

export default function EmployeeForm() {
  const [formData, setFormData] = useState({
    name: "",
    position: "",
    department: "",
    salary: ""
  });

  const handleChange = (e) => {
    setFormData({...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await api.post("/employees", formData);
    alert("Employee added!");
  };

  return (
    <form className="p-4" onSubmit={handleSubmit}>
      <h2 className="text-xl font-bold mb-4">Add New Employee</h2>
      <input className="block mb-2" name="name" onChange={handleChange} placeholder="Name" />
      <input className="block mb-2" name="position" onChange={handleChange} placeholder="Position" />
      <input className="block mb-2" name="department" onChange={handleChange} placeholder="Department" />
      <input className="block mb-2" name="salary" onChange={handleChange} placeholder="Salary" />
      <button type="submit" className="bg-blue-600 text-white p-2">Add Employee</button>
    </form>
  );
}
