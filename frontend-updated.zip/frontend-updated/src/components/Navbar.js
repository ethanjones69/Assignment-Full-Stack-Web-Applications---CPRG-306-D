export default function Navbar() {
  return (
    <nav className="bg-blue-700 text-white p-4">
      <h1 className="text-xl font-semibold">IMR Movie Portal</h1>
    </nav>
  );
}
