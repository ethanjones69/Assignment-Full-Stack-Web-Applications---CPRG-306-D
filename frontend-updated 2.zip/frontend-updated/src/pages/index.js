import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import axios from 'axios';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import MovieForm from '@/components/MovieForm';

export default function Home() {
  const router = useRouter();
  const [movies, setMovies] = useState([]);

  const fetchMovies = async () => {
    const res = await axios.get('http://localhost:3000/api/movies');
    setMovies(res.data);
  };

  const deleteMovie = async (id) => {
    await axios.delete(`http://localhost:3000/api/movies/${id}`);
    fetchMovies();
  };

  useEffect(() => {
    const user = localStorage.getItem('user');
    if (!user) {
      router.push('/login');
    } else {
      fetchMovies();
    }
  }, []);

  return (
    <div>
      <Navbar />
      <main className="p-6 max-w-4xl mx-auto">
        <MovieForm fetchMovies={fetchMovies} />
        <h2 className="text-2xl font-semibold mt-8 mb-4">Movie List</h2>
        <div className="space-y-4">
          {movies.map(movie => (
            <div key={movie.id} className="bg-white p-4 shadow rounded">
              <h3 className="text-lg font-bold">{movie.title} ({movie.year})</h3>
              <p className="text-sm text-gray-700">Actors: {movie.actors.join(', ')}</p>
              <button onClick={() => deleteMovie(movie.id)} className="text-red-600 text-sm mt-2">Delete</button>
            </div>
          ))}
        </div>
        <button
          onClick={() => {
            localStorage.removeItem('user');
            router.push('/login');
          }}
          className="text-sm text-blue-600 mt-6"
        >
          Logout
        </button>
      </main>
      <Footer />
    </div>
  );
}
